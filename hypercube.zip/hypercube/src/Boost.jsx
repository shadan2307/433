import React from 'react'
import Footer from './Footer'
import { Link } from 'react-router-dom'
import bat from '../public/bat.png'
import bot from '../public/bot.png'
import g from '../public/g.png'
import highVoltage from '../public/high-voltage.png';
const Boost = () => {
  return (
    <>
      <div style={{ display: 'flex', flexDirection: 'column', gap: '30px' }}>


        <div className='button' style={{
          display: 'flex', alignItems: 'center', justifyContent: 'start', border: '1px solid rgb(67, 67, 67)', borderRadius: '8px', cursor: 'pointer', textDecoration: 'none', paddingRight: '104px'
        }}>
          <img style={{}} src={bat} height={"60px"} width="" alt="" />

          <div style={{ margin: '-15px', display: 'flex', fontWeight: 'bold', flexDirection: 'column', alignItems: 'start', justifyContent: 'start' }}>
            <div>Energy Limit</div>
            <div style={{ fontWeight: '400', fontSize: '13px', color: '#f9f9f9', display: 'flex', alignItems: 'start', justifyContent: 'start' }} >&nbsp; <img src={g} height={"15px"} alt="" /> <div>2000</div>
            </div>

          </div>
        </div>


        <div className='button' style={{
          display: 'flex', alignItems: 'center', justifyContent: 'start', border: '1px solid rgb(67, 67, 67)', borderRadius: '8px', cursor: 'pointer', textDecoration: 'none', paddingRight: '104px', padding: '10px'
        }}>
          <img style={{}} src={highVoltage} height={"30px"} width="" alt="" />

          <div style={{ margin: '1px', display: 'flex', fontWeight: 'bold', flexDirection: 'column', alignItems: 'start', justifyContent: 'start' }}>
            <div>Recharging Speed</div>
            <div style={{ fontWeight: '400', fontSize: '13px', color: '#f9f9f9', display: 'flex', alignItems: 'start', justifyContent: 'start' }} >&nbsp; <img src={g} height={"15px"} alt="" /> <div>100 000</div>
            </div>

          </div>
        </div>




        <div className='button' style={{
          display: 'flex', alignItems: 'center', justifyContent: 'start', border: '1px solid rgb(67, 67, 67)', borderRadius: '8px', cursor: 'pointer', textDecoration: 'none', paddingRight: '104px'
        }}>
          <img style={{}} src={bot} height={"60px"} width="" alt="" /> &nbsp;

          <div style={{ margin: '-15px', display: 'flex', fontWeight: 'bold', flexDirection: 'column', alignItems: 'start', justifyContent: 'start' }}>
            <div>Tap Bot</div>
            <div style={{ fontWeight: '400', fontSize: '13px', color: '#f9f9f9', display: 'flex', alignItems: 'start', justifyContent: 'start' }} >&nbsp; <img src={g} height={"15px"} alt="" /> <div>200 000</div>
            </div>

          </div>
        </div>




      </div>

    </>
  )
}

export default Boost