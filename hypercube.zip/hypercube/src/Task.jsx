import React from 'react'
import Footer from './Footer'
import utube from '../public/utube.png'
import c from '../public/c.png'
import g from '../public/g.png'
import twitter from '../public/twitter.png'
import whatsapp from '../public/whatsapp.png'

const Task = () => {
  const handleClick = () => {
    window.open('https://www.youtube.com/watch?v=7QU1nvuxaMA', '_blank');
  };

  return (
    <>
      <div style={{ padding: '40px 20px 40px 20px', display: 'flex', flexDirection: 'column', gap: '20px' }}>


        <div onClick={handleClick} className='button' style={{ display: 'flex', alignItems: 'center', border: '1px solid rgb(67, 67, 67)', padding: '10px', borderRadius: '8px', cursor: 'pointer', textDecoration: 'none' }}>
          <img src={utube} height={"20px"} alt="" />
          <div style={{ display: 'flex', alignItems: 'center' }}> Watch Video & Earn  </div> &nbsp; <img src={g} height={"10px"} alt="" />
        </div>


        <div onClick={handleClick} className='button' style={{ display: 'flex', alignItems: 'center', border: '1px solid rgb(67, 67, 67)', padding: '10px', borderRadius: '8px', cursor: 'pointer', textDecoration: 'none' }}>
          <img src={utube} height={"20px"} alt="" />
          <div style={{ display: 'flex', alignItems: 'center' }}> Watch Video & Earn  </div> &nbsp; <img src={g} height={"10px"} alt="" />
        </div>


        <div onClick={handleClick} className='button' style={{ display: 'flex', alignItems: 'center', border: '1px solid rgb(67, 67, 67)', padding: '10px', borderRadius: '8px', cursor: 'pointer', textDecoration: 'none' }}>
          <img src={twitter} height={"20px"} alt="" />
          <div style={{ display: 'flex', alignItems: 'center' }}> Watch Video & Earn  </div> &nbsp; <img src={g} height={"10px"} alt="" />
        </div>


        <div onClick={handleClick} className='button' style={{ display: 'flex', alignItems: 'center', border: '1px solid rgb(67, 67, 67)', padding: '10px', borderRadius: '8px', cursor: 'pointer', textDecoration: 'none' }}>
          <img src={whatsapp} height={"20px"} alt="" />
          <div style={{ display: 'flex', alignItems: 'center' }}> Watch Video & Earn  </div> &nbsp; <img src={g} height={"10px"} alt="" />
        </div>



      </div>


      {/* <Footer></Footer>   */}

    </>
  )
}

export default Task