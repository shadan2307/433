// src/DailyButton.js
import React, { useState, useEffect } from 'react';

const DailyTask = () => {
    const [isDisabled, setIsDisabled] = useState(false);
    const [clickCount, setClickCount] = useState(0);

    useEffect(() => {
        // Load the last click time and click count from local storage
        const lastClickTime = localStorage.getItem('lastClickTime');
        const storedClickCount = localStorage.getItem('clickCount');

        // Parse the stored values
        const lastClickDate = lastClickTime ? new Date(lastClickTime) : null;
        const count = storedClickCount ? parseInt(storedClickCount, 10) : 0;

        if (lastClickDate && count) {
            // Calculate the difference between now and the last click time
            const now = new Date();
            const timeDiff = now - lastClickDate;
            const hoursDiff = timeDiff / (1000 * 60 * 60);

            // Enable the button if more than 24 hours have passed
            if (hoursDiff >= 24) {
                setIsDisabled(false);
            } else {
                setIsDisabled(true);
            }

            setClickCount(count);
        }
    }, []);

    const handleClick = () => {
        const now = new Date();

        // Save the current time and increment the click count
        localStorage.setItem('lastClickTime', now.toISOString());
        localStorage.setItem('clickCount', clickCount + 1);

        setClickCount(clickCount + 1);
        setIsDisabled(true);
    };

    return (
        <div>
            <button onClick={handleClick} disabled={isDisabled || clickCount >= 3}>
                Click Me
            </button>
            <p>You have clicked {clickCount} times.</p>
            {clickCount >= 3 && <p>You can't click anymore for the next 3 days.</p>}
        </div>
    );
};

export default DailyTask;
