import React from 'react'
import Footer from './Footer'
import { Link } from 'react-router-dom'
import g from '../public/g.png'
import DailyTask from './DailyTask'

const Stat = () => {

  const handleClick = () => {
    window.open('https://www.youtube.com/watch?v=7QU1nvuxaMA', '_blank');
  };


  const anotherBtn = () => {

    const url_to_Wh = ""
    window.open(url_to_Wh);
  }
  return (
    <>


      <div style={{ padding: '40px 20px 40px 20px', display: 'flex', flexDirection: 'column', gap: '20px' }}>

        <DailyTask></DailyTask>
        <div onClick={handleClick} className='button' style={{ display: 'flex', gap: '20px', alignItems: 'center', border: '1px solid rgb(67, 67, 67)', padding: '10px', borderRadius: '8px', cursor: 'pointer', textDecoration: 'none' }}>
          <img src={g} height={"20px"} alt="" />
          <div style={{ display: 'flex', alignItems: 'center' }}> Refer & Earn </div>
        </div>


      </div>
      <div style={{
        height: '200px'
      }}></div>


    </>
  )
}

export default Stat