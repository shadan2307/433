import { useState, useEffect } from 'react'
import './App.css'
import coin from '../public/coin2.png'
import c from '../public/c.png'
import g from '../public/g.png'
import f from '../public/f.png'
import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom';
import Task from './Task'
import Apps from './Apps'
import Stat from './Stat'
import Boost from './Boost'
import t from '../public/t.png'
import s from '../public/s.png'
import Home from './Home'
import r from '../public/r.png'
import Footer from './Footer'
import Levels from './Levels'

function App() {
  const [coin, setCoin] = useState(87900.76)

  const getCoin = () => {
    setCoin(prevCoin => prevCoin + 1043);
  }

  useEffect(() => {

    console.log("Rendered Called ")

  }, [])

  return (
    <>
      <Router>

        <Routes>
          <Route path="/" element={<Home />} >
            <Route path="/home" element={<Apps />} />
            <Route path="/levels" element={<Levels />} />
            <Route path="/task" element={<Task />} />
            <Route path="/stat" element={<Stat />} />
            <Route path="/boost" element={<Boost />} />
          </Route>
        </Routes>

      </Router>

    </>
  )
}

export default App
