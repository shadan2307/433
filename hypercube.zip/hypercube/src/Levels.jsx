import React, { useState } from 'react'
import one from '../public/1.png'
import two from '../public/2.png'
import three from '../public/3.png'
import four from '../public/4.png'

const Levels = () => {

    const [imgno, setfirst] = useState(1);

    const forward = () => {

        setfirst(pre => pre + 1)

    }

    const back = () => {
        setfirst(pre => pre - 1)

    }


    return (
        <div style={{ display: 'flex', flexDirection: 'column', justifyContent: 'center', alignItems: 'center', gap: '50px' }}>

            <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', flexDirection: 'column' }}>
                <div style={{ fontSize: '30px' }}>Bronze</div>
                <div>your share determine the level</div>
            </div>
            <div style={{ padding: '', display: 'flex' }}>
                <div onClick={back} style={{ backgroundColor: '', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '25px' }}>&lt;</div>
                <div style={{
                    display: 'flex', justifyContent: 'center', alignItems: 'center'
                }}>

                    <img src={`../public/${imgno}.png`} height={200} alt="" />

                </div>
                <div onClick={forward} style={{ backgroundColor: '', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '25px' }}>&gt;</div>
            </div>

            <div>FROM 50,000</div>
            <div style={{
                backgroundColor: '#f9c035', borderRadius: '9px', width: '100%'
            }} >
                <div className='progress-fill' style={{ width: `${(260 / 500) * 100}%`, backgroundColor: 'green' }}></div>
            </div>


        </div>
    )
}

export default Levels