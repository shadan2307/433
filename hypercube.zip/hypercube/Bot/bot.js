import { Telegraf } from "telegraf"
import { message } from "telegraf/filters"
const Token = "7384018713:AAG7JpmArxlW51-yH2NtaSUqS0R7q7HoBDM"
const bot = new Telegraf(Token)
bot.start((ctx) => ctx.reply('https://t.me/Hypercube_tech_bot/hypercube'))

bot.help((ctx) => ctx.reply('Send me a sticker'))
bot.on(message('sticker'), (ctx) => ctx.reply('👍'))
bot.hears('hi', (ctx) => ctx.reply('Hey there'))
bot.launch()